package dev.flutter.dah2021_suarez2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
